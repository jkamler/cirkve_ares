
--
-- Indexes for dumped tables
--

--
-- Indexes for table `RUIAN_data`
--
ALTER TABLE `RUIAN_data`
  ADD KEY `index_obec_cast_obce_ulice_cp_psc` (`Nazev_obce`,`Nazev_casti_obce`,`Nazev_ulice`,`Cislo_do_adresy`,`PSC`),
  ADD KEY `index_obec_cast_obce_ulice_cp` (`Nazev_obce`,`Nazev_casti_obce`,`Nazev_ulice`,`Cislo_do_adresy`);
